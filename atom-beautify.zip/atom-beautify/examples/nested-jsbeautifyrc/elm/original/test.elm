addThings x y = x + y

main = addThings 4 5
