# duotone denim syntax

## Description

A double-hue syntax theme for Atom.
This is a dark blue scheme based on [duotone dark syntax theme](https://github.com/simurai/duotone-dark-syntax) by [simurai](https://github.com/simurai).

## Installation

```shell
apm install duotone-denim-syntax
```

## Screenshot

![duotone denim syntax theme screenshot](https://cdn.rawgit.com/varemenos/duotone-denim-syntax/master/screenshot.png)

## License

the MIT License (MIT)
