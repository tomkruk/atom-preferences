<a name="0.2.0"></a>
# 0.2.0 (2015-12-11)

## :sparkles: Features

- Implement destroying bindings on deactivation ([a58c8508](https://github.com/atom-minimap/minimap-bookmarks/commit/a58c8508dcf1e7e65bb1f86d6e07bb1639a26f9d))
- Implement retrieving existing markers and destroying decorations along binding ([3dc7ae07](https://github.com/atom-minimap/minimap-bookmarks/commit/3dc7ae07d6179be70fc823c953c68cb8e0c986ff))
