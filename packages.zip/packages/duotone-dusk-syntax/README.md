# duotone dusk syntax

## Description

A double-hue syntax theme for Atom.
This is a dark blue scheme based on [duotone dark syntax theme](https://github.com/simurai/duotone-dark-syntax) by [simurai](https://github.com/simurai).

## Installation

```shell
apm install duotone-dusk-syntax
```

## Screenshot

![duotone dusk syntax theme screenshot](https://cdn.rawgit.com/varemenos/duotone-dusk-syntax/master/screenshot.png)

## License

the MIT License (MIT)
