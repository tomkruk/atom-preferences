# DuoTone Dark Space (muted) Theme

A double-hue syntax theme for Atom.

Like duotone-dark-space-syntax, but the orange isn't quite so in-your-face.
