# gooey-syntax theme

### premise
A greeny-blue theme with purple/red hints.
Inspired after seeing [@mrmrs_](https://twitter.com/mrmrs_)'s terminal theme while he was giving a talk on CSS. It was delicious!

### conclusion
I hope you loves it! 🌟

### example 
![Example CSS/LESS/SCSS styling](https://raw.githubusercontent.com/simeydotme/atom-gooey-syntax/master/screenshot.png)
